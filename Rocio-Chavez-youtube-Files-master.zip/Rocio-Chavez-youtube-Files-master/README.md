# Rocio-Chavez-youtube-Files

En este repositorio encontrarás los archivos que utilizo para los videos de mi canal de youtube, el cual se encuentra en: 

https://www.youtube.com/user/rociochavezmx/about?view_as=public

En este canal podrás encontrar videos de Machine Learning,  Estadística y de Matemáticas en general aplicadas a los negocios,
en los que te explicaré de manera muy detallada técnicas que te serán de gran utilidad si quieres transformar tus datos 
en información o bien adquirir los conocimientos básicos que se requieren en el área de la inteligencia artificial.
